export interface CardData { tag?: string; title: string; desc: string; img: string }
export interface Post { title: string; tag: string; intro: string; items: { b?: string; t: string }[]; outro: string }

export const cargoCards: CardData[] = [
  { tag: "Transportadores", title: "RCTR-C e RC-DC", desc: "Cobertura de responsabilidade civil do transportador rodoviário por danos e desaparecimento da carga transportada.", img: "truck" },
  { tag: "Embarcadores", title: "Transporte nacional", desc: "Proteção para mercadorias de quem contrata o frete, com averbação das viagens e coberturas conforme a mercadoria.", img: "ware" },
  { tag: "Comércio exterior", title: "Transporte internacional", desc: "Seguro para importação e exportação, por via rodoviária, marítima ou aérea.", img: "ship" },
  { tag: "Frotas", title: "RC-V e seguro de frota", desc: "Responsabilidade civil por danos a terceiros e proteção aos veículos da sua operação.", img: "fleet" },
];

export const companyLines = ["Carga e transporte", "Frota", "Empresarial", "Responsabilidade civil", "Risco de engenharia", "Seguro de vida em grupo", "Garantia"];
export const personLines = ["Residencial", "Vida", "Viagem", "Previdência"];

export const profileCards: CardData[] = [
  { title: "Transportadoras", desc: "Apólices obrigatórias e facultativas, e revisão de limites conforme a carga.", img: "truck" },
  { title: "Indústria e comércio", desc: "Cargas embarcadas, patrimônio e proteção da operação em um programa de seguros.", img: "fact" },
  { title: "Obras e projetos", desc: "Coberturas de risco de engenharia para construtoras e empreendimentos.", img: "build" },
  { title: "Famílias", desc: "Seguro de carro, casa e vida com cotação em várias seguradoras.", img: "fam" },
];

export const whyItems = [
  { t: "Cotação em várias seguradoras", d: "Você compara preço e cobertura antes de decidir." },
  { t: "Atendimento direto", d: "Fale com quem cuida da sua apólice, pelo WhatsApp ou e-mail." },
  { t: "Apoio no sinistro", d: "Orientamos a documentação e acompanhamos o processo até o fim." },
  { t: "Revisão periódica", d: "Reavaliamos suas apólices a cada renovação para ajustar coberturas e custo." },
];

export const posts: Post[] = [
  {
    title: "RCTR-C, RC-DC e RC-V: qual a diferença?", tag: "Seguro de carga",
    intro: "As três siglas aparecem na contratação de seguro para transportadores e são coberturas diferentes:",
    items: [
      { b: "RCTR-C:", t: "responsabilidade do transportador por perdas e danos à carga em acidentes, como colisão, tombamento e incêndio." },
      { b: "RC-DC:", t: "responsabilidade por desaparecimento da carga, como roubo, furto e extravio." },
      { b: "RC-V:", t: "responsabilidade por danos materiais e corporais a terceiros causados pelo veículo." },
    ],
    outro: "A legislação do transporte rodoviário de cargas exige parte dessas coberturas. Confirme com seu corretor quais se aplicam à sua operação e se os limites cobrem o valor das mercadorias.",
  },
  {
    title: "Como reduzir o custo do seguro da frota", tag: "Frotas",
    intro: "O preço do seguro reflete o risco. Alguns pontos ajudam a melhorar o perfil da operação:",
    items: [
      { t: "Rastreamento e monitoramento dos veículos." },
      { t: "Gerenciamento de risco e treinamento dos motoristas." },
      { t: "Histórico de sinistros baixo e bem documentado." },
      { t: "Cotação em mais de uma seguradora a cada renovação." },
    ],
    outro: "Peça uma análise da sua frota: avaliamos o perfil e buscamos as melhores condições do mercado.",
  },
  {
    title: "O que fazer quando ocorre um sinistro com a carga", tag: "Sinistro",
    intro: "Siga estes passos e avise a corretora o quanto antes:",
    items: [
      { t: "Garanta a segurança das pessoas e acione as autoridades." },
      { t: "Registre o boletim de ocorrência." },
      { t: "Fotografe o local, o veículo e a carga." },
      { t: "Reúna os documentos da viagem, como nota fiscal, CT-e e MDF-e." },
      { t: "Não remova ou descarte a carga sem orientação da seguradora." },
    ],
    outro: "Quanto mais rápido o aviso, mais ágil é a análise do sinistro.",
  },
];

export const insuranceOptions = ["Carga e transporte", "Frota", "Empresarial", "Risco de engenharia", "Automóvel", "Residencial", "Vida", "Outro"];

export const partners = ["Tokio Marine", "Allianz", "Porto Seguro", "Yelum", "HDI", "AXA"];
