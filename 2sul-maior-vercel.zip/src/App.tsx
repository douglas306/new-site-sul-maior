import { Header } from "@/components/Header";
import { CargoSection } from "@/components/CargoSection";
import { Portfolio } from "@/components/Portfolio";
import { Why } from "@/components/Why";
import { Partners } from "@/components/Partners";
import { Blog } from "@/components/Blog";
import { Contact } from "@/components/Contact";
import { Footer } from "@/components/Footer";

export default function App() {
  return (
    <>
      <Header />
      <main>
        <CargoSection />
        <Portfolio />
        <Why />
        <Partners />
        <Blog />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
