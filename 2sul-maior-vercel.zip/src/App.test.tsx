import { render, screen } from "@testing-library/react";
import App from "./App";

describe("App", () => {
  it("renderiza as seções principais", () => {
    render(<App />);
    expect(screen.getByRole("heading", { level: 1, name: /Sua carga protegida/ })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: /Portfólio de seguros/ })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: /Blog: dicas de seguros/ })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: /Peça sua cotação/ })).toBeInTheDocument();
  });
  it("tem 8 cartões que viram", () => {
    const { container } = render(<App />);
    expect(container.querySelectorAll(".flip")).toHaveLength(8);
  });
  it("botão Automóvel abre o WhatsApp com os campos a preencher", () => {
    render(<App />);
    const link = screen.getByRole("link", { name: /Automóvel/ });
    expect(decodeURIComponent(link.getAttribute("href")!)).toContain("CPF:");
  });
  it("lista os três artigos do blog", () => {
    const { container } = render(<App />);
    expect(container.querySelectorAll("details")).toHaveLength(3);
  });
  it("menu superior: Seguros, Nossos parceiros, Blog e Contato", () => {
    render(<App />);
    const nav = screen.getByRole("navigation", { name: "Principal" });
    const links = Array.from(nav.querySelectorAll("a")).map((a) => [a.textContent, a.getAttribute("href")]);
    expect(links).toEqual([["Seguros", "#portfolio"], ["Nossos parceiros", "#parceiros"], ["Blog", "#blog"], ["Contato", "#contato"]]);
  });
  it("lista as seis seguradoras parceiras", () => {
    const { container } = render(<App />);
    expect(container.querySelectorAll("#parceiros article")).toHaveLength(6);
    expect(screen.getByRole("heading", { name: "Tokio Marine" })).toBeInTheDocument();
  });
});
