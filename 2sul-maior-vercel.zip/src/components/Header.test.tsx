import { render, screen, fireEvent } from "@testing-library/react";
import { Header, HERO_PHOTO } from "./Header";

describe("Header", () => {
  it("usa a foto do caminhão e volta à ilustração se o arquivo não existir", () => {
    const { container } = render(<Header />);
    const img = container.querySelector(".scene img") as HTMLImageElement;
    expect(img.getAttribute("src")).toBe(HERO_PHOTO);
    fireEvent.error(img);
    expect(img.getAttribute("src")).not.toBe(HERO_PHOTO);
    expect(screen.getByRole("img", { name: /Caminhão/ })).toBeInTheDocument();
  });
});
