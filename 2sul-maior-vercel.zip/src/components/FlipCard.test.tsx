import { render, screen, fireEvent } from "@testing-library/react";
import { FlipCard } from "./FlipCard";

const props = { tag: "Transportadores", title: "RCTR-C e RC-DC", desc: "Descrição", img: "truck" };

describe("FlipCard", () => {
  it("mostra título, descrição e link de cotação no WhatsApp", () => {
    render(<FlipCard {...props} />);
    expect(screen.getAllByText("RCTR-C e RC-DC").length).toBeGreaterThan(0);
    expect(screen.getByText("Descrição")).toBeInTheDocument();
    const link = screen.getByRole("link", { name: /Pedir cotação/ });
    expect(link).toHaveAttribute("href", expect.stringContaining("https://wa.me/5551998582806?text="));
  });
  it("vira ao toque em telas sem hover", () => {
    window.matchMedia = vi.fn().mockReturnValue({ matches: true }) as unknown as typeof window.matchMedia;
    render(<FlipCard {...props} />);
    const card = screen.getByRole("group", { name: "RCTR-C e RC-DC" });
    expect(card).not.toHaveClass("on");
    fireEvent.click(card);
    expect(card).toHaveClass("on");
  });
});
