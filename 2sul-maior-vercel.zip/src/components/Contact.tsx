import { useState, type FormEvent } from "react";
import { insuranceOptions } from "@/data/content";
import { EMAIL, PHONE_LABEL, contactMessage, waUrl } from "@/lib/whatsapp";

export function Contact() {
  const [seg, setSeg] = useState(insuranceOptions[0]);
  const onSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const d = new FormData(e.currentTarget);
    const text = contactMessage({ nome: String(d.get("nome")), tel: String(d.get("tel")), seg, msg: String(d.get("msg") || "") });
    window.open(waUrl(text), "_blank", "noopener");
  };
  return (
    <section className="contact" id="contato">
      <div className="wrap box">
        <div>
          <h2>Peça sua cotação</h2>
          <p>Conte o que você quer proteger. Respondemos pelo WhatsApp com uma proposta personalizada.</p>
          <div className="info">
            <span>Porto Alegre, RS</span>
            <a href={waUrl()} target="_blank" rel="noopener noreferrer">WhatsApp {PHONE_LABEL}</a>
            <a href={`mailto:${EMAIL}`}>{EMAIL}</a>
          </div>
        </div>
        <form onSubmit={onSubmit}>
          <label>Nome<input name="nome" required autoComplete="name" /></label>
          <label>Telefone com DDD<input name="tel" type="tel" required autoComplete="tel" placeholder="(51) 90000-0000" /></label>
          <label>Seguro de interesse
            <select name="seg" value={seg} onChange={(e) => setSeg(e.target.value)}>
              {insuranceOptions.map((o) => <option key={o}>{o}</option>)}
            </select>
          </label>
          <label>Mensagem<textarea name="msg" rows={3} /></label>
          <button className="btn btn-wa" type="submit">Enviar pelo WhatsApp</button>
          <small>Ao enviar, o WhatsApp abre com sua mensagem pronta. Prefere e-mail? <a href={`mailto:${EMAIL}`}>Escreva para a gente</a>.</small>
        </form>
      </div>
    </section>
  );
}
