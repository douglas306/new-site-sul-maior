import { companyLines, personLines, profileCards } from "@/data/content";
import { AUTO_QUOTE_MESSAGE, waUrl } from "@/lib/whatsapp";
import { FlipCard } from "./FlipCard";

export function Portfolio() {
  return (
    <section className="alt" id="portfolio">
      <div className="wrap">
        <div className="head">
          <h2>Portfólio de seguros</h2>
          <p>Além de carga, a Sul Maior trabalha com todas as linhas. Você centraliza as apólices da família e da empresa em uma só corretora.</p>
        </div>
        <h3 style={{ marginBottom: 14 }}>Para empresas</h3>
        <ul className="lines">{companyLines.map((l) => <li key={l}>{l}</li>)}</ul>
        <h3 style={{ margin: "32px 0 14px" }}>Para pessoas</h3>
        <ul className="lines">
          <li className="go">
            <a href={waUrl(AUTO_QUOTE_MESSAGE)} target="_blank" rel="noopener noreferrer" title="Cotar seguro automóvel pelo WhatsApp">
              Automóvel · Cotar no WhatsApp →
            </a>
          </li>
          {personLines.map((l) => <li key={l}>{l}</li>)}
        </ul>
        <div className="grid" style={{ marginTop: 44 }}>
          {profileCards.map((c) => <FlipCard key={c.title} {...c} />)}
        </div>
      </div>
    </section>
  );
}
