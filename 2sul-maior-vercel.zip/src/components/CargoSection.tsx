import { cargoCards } from "@/data/content";
import { FlipCard } from "./FlipCard";

export function CargoSection() {
  return (
    <section id="carga">
      <div className="wrap">
        <div className="head">
          <h2>Especialistas em seguro de carga e transporte</h2>
          <p>Cada operação tem uma rota, um tipo de mercadoria e um risco. Montamos a cobertura sob medida e acompanhamos você até o sinistro, se ele acontecer.</p>
        </div>
        <div className="grid">{cargoCards.map((c) => <FlipCard key={c.title} {...c} />)}</div>
      </div>
    </section>
  );
}
