import { partners } from "@/data/content";
import { interestMessage, waUrl } from "@/lib/whatsapp";

export function Partners() {
  return (
    <section className="alt" id="parceiros">
      <div className="wrap">
        <div className="head">
          <h2>Nossos parceiros</h2>
          <p>Cotamos o seu seguro em várias seguradoras e apresentamos a melhor combinação de preço e cobertura para você.</p>
        </div>
        <div className="ins">
          {partners.map((p) => (
            <article className="p" key={p}>
              <h3>{p}</h3>
              <a href={waUrl(interestMessage(`seguro na ${p}`))} target="_blank" rel="noopener noreferrer">Pedir cotação na {p}</a>
            </article>
          ))}
        </div>
        <p className="note">Os nomes pertencem às respectivas seguradoras. A disponibilidade de produtos, as condições e a aceitação do risco dependem de cada seguradora.</p>
      </div>
    </section>
  );
}
