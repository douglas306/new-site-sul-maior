import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { Contact } from "./Contact";

describe("Contact", () => {
  it("abre o WhatsApp com a mensagem preenchida", async () => {
    const open = vi.spyOn(window, "open").mockImplementation(() => null);
    render(<Contact />);
    await userEvent.type(screen.getByLabelText("Nome"), "Maria");
    await userEvent.type(screen.getByLabelText(/Telefone/), "(51) 99999-0000");
    await userEvent.selectOptions(screen.getByLabelText(/Seguro de interesse/), "Frota");
    await userEvent.click(screen.getByRole("button", { name: /Enviar pelo WhatsApp/ }));
    expect(open).toHaveBeenCalledTimes(1);
    const url = String(open.mock.calls[0][0]);
    expect(url).toContain("https://wa.me/5551998582806?text=");
    expect(decodeURIComponent(url)).toContain("Olá, sou Maria. Tenho interesse em seguro de Frota.");
  });
  it("não envia sem nome e telefone", async () => {
    const open = vi.spyOn(window, "open").mockImplementation(() => null);
    open.mockClear();
    render(<Contact />);
    await userEvent.click(screen.getByRole("button", { name: /Enviar pelo WhatsApp/ }));
    expect(open).not.toHaveBeenCalled();
  });
});
