import { useState } from "react";
import logo from "@/assets/logo.png";
import heroUrl from "@/assets/hero.svg";
import { GENERIC_MESSAGE, waUrl } from "@/lib/whatsapp";

export const HERO_PHOTO = "/images/hero-caminhao.jpg";

export function Header() {
  const [heroSrc, setHeroSrc] = useState(HERO_PHOTO);
  return (
    <header className="hero">
      <div className="wrap">
        <div className="top">
          <a href="#topo" aria-label="Sul Maior Corretora"><img src={logo} alt="Sul Maior Corretora de Seguros" /></a>
          <nav aria-label="Principal">
            <a href="#portfolio">Seguros</a>
            <a href="#parceiros">Nossos parceiros</a>
            <a href="#blog">Blog</a>
            <a href="#contato">Contato</a>
          </nav>
          <a className="btn btn-wa" href={waUrl(GENERIC_MESSAGE)} target="_blank" rel="noopener noreferrer">WhatsApp</a>
        </div>
        <div className="hero-grid" id="topo">
          <div>
            <h1>Sua carga protegida do embarque à entrega.</h1>
            <p>A Sul Maior Corretora, de Porto Alegre, é especialista em seguro de carga e transporte e atende todas as linhas de seguro para pessoas e empresas.</p>
            <div className="cta">
              <a className="btn btn-wa" href="#contato">Pedir cotação</a>
              <a className="btn btn-line" href="#carga">Ver seguros de carga</a>
            </div>
          </div>
          <div className="scene" role="img" aria-label="Caminhão transportando carga em uma estrada">
            <img src={heroSrc} alt="" onError={() => setHeroSrc(heroUrl)} />
          </div>
        </div>
      </div>
    </header>
  );
}
