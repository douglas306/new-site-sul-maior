import { useState, type MouseEvent } from "react";
import { interestMessage, waUrl } from "@/lib/whatsapp";
import type { CardData } from "@/data/content";

const isTouch = () => typeof window.matchMedia === "function" && window.matchMedia("(hover:none)").matches;

export function FlipCard({ tag, title, desc, img }: CardData) {
  const [on, setOn] = useState(false);
  const onClick = (e: MouseEvent) => {
    if ((e.target as HTMLElement).closest("a")) return;
    if (isTouch()) setOn((v) => !v);
  };
  return (
    <article className={"flip" + (on ? " on" : "")} tabIndex={0} role="group" aria-label={title} onClick={onClick}>
      <div className="flip-in">
        <div className={"face front" + (tag ? " big" : "")}>
          {tag && <span className="tag">{tag}</span>}
          <h3>{title}</h3>
          <p>{desc}</p>
        </div>
        <div className={`face back i-${img}`}>
          <h3>{title}</h3>
          <a className="btn btn-wa" href={waUrl(interestMessage(title))} target="_blank" rel="noopener noreferrer">
            Pedir cotação
          </a>
        </div>
      </div>
    </article>
  );
}
