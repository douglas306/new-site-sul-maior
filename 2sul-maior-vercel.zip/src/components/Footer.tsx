import { waUrl } from "@/lib/whatsapp";

export function Footer() {
  return (
    <>
      <footer>
        <div className="wrap">
          <span>© 2026 Sul Maior Corretora de Seguros · Porto Alegre, RS</span>
          <span>Registro de corretor nº 719684</span>
        </div>
      </footer>
      <a className="btn btn-wa fab" href={waUrl()} target="_blank" rel="noopener noreferrer" aria-label="Falar pelo WhatsApp">WhatsApp</a>
    </>
  );
}
