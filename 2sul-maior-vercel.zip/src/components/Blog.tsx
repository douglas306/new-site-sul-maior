import { posts } from "@/data/content";

export function Blog() {
  return (
    <section id="blog">
      <div className="wrap">
        <div className="head">
          <h2>Blog: dicas de seguros</h2>
          <p>Conteúdo prático para você contratar melhor e se proteger.</p>
        </div>
        {posts.map((p) => (
          <details key={p.title}>
            <summary>{p.title}</summary>
            <small>{p.tag}</small>
            <div className="body">
              <p>{p.intro}</p>
              <ul>{p.items.map((i) => <li key={i.t}>{i.b && <b>{i.b} </b>}{i.t}</li>)}</ul>
              <p>{p.outro}</p>
            </div>
          </details>
        ))}
      </div>
    </section>
  );
}
