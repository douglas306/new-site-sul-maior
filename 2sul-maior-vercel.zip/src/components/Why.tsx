import { whyItems } from "@/data/content";

export function Why() {
  return (
    <section>
      <div className="wrap why">
        <div className="head" style={{ margin: 0 }}>
          <h2>Por que contratar uma corretora</h2>
          <p>O corretor trabalha para você, não para a seguradora. Comparamos propostas, explicamos as cláusulas e estamos ao seu lado na hora do sinistro.</p>
        </div>
        <ul>{whyItems.map((w) => <li key={w.t}><strong>{w.t}</strong>{w.d}</li>)}</ul>
      </div>
    </section>
  );
}
