import { AUTO_QUOTE_MESSAGE, PHONE, contactMessage, interestMessage, waUrl } from "./whatsapp";

describe("whatsapp", () => {
  it("monta o link sem texto", () => {
    expect(waUrl()).toBe(`https://wa.me/${PHONE}`);
  });
  it("codifica o texto na URL", () => {
    const url = waUrl("Olá, tudo bem?");
    expect(url).toContain("?text=");
    expect(decodeURIComponent(url.split("?text=")[1])).toBe("Olá, tudo bem?");
  });
  it("mensagem de interesse cita o seguro", () => {
    expect(interestMessage("Frota")).toContain("Frota");
  });
  it("mensagem de automóvel traz os campos a preencher", () => {
    for (const campo of ["Nome:", "CPF:", "Data de nascimento:", "Estado civil:", "Veículo:", "Placa ou chassi:", "CEP residencial:", "Seguro novo ou possui bônus?"]) {
      expect(AUTO_QUOTE_MESSAGE).toContain(campo);
    }
  });
  it("mensagem de contato inclui a observação só quando existe", () => {
    const base = { nome: "Ana", tel: "(51) 90000-0000", seg: "Vida" };
    expect(contactMessage(base)).toBe("Olá, sou Ana. Tenho interesse em seguro de Vida. Meu telefone: (51) 90000-0000.");
    expect(contactMessage({ ...base, msg: "Urgente" })).toMatch(/ Urgente$/);
  });
});
