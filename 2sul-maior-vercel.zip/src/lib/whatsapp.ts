export const PHONE = "5551998582806";
export const PHONE_LABEL = "(51) 99858-2806";
export const EMAIL = "sulmaiorseguros@sulmaior.com.br";

export const waUrl = (text?: string) =>
  `https://wa.me/${PHONE}` + (text ? `?text=${encodeURIComponent(text)}` : "");

export const interestMessage = (title: string) =>
  `Olá, tenho interesse em ${title}. Podem me ajudar com uma cotação?`;

export const GENERIC_MESSAGE = "Olá, vim pelo site e quero uma cotação.";

export const AUTO_QUOTE_MESSAGE = `Olá! Quero uma cotação de seguro automóvel. Seguem meus dados:

Nome:
CPF:
Data de nascimento:
Estado civil:
Veículo:
Placa ou chassi:
CEP residencial:
Seguro novo ou possui bônus?`;

export interface ContactData {
  nome: string;
  tel: string;
  seg: string;
  msg?: string;
}

export const contactMessage = ({ nome, tel, seg, msg }: ContactData) =>
  `Olá, sou ${nome}. Tenho interesse em seguro de ${seg}. Meu telefone: ${tel}.` +
  (msg ? ` ${msg}` : "");
