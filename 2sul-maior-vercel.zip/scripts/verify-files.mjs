// Confere se os arquivos essenciais chegaram ao repositório antes do build.
import { existsSync, readdirSync } from "node:fs";

const required = [
  "index.html",
  "package.json",
  "src/main.tsx",
  "src/App.tsx",
  "src/styles.css",
  "src/components/Header.tsx",
  "src/assets/logo.png",
  "src/assets/hero.svg",
];
const missing = required.filter((f) => !existsSync(f));
if (missing.length) {
  console.error("\nERRO: arquivos do projeto não encontrados no repositório:");
  for (const f of missing) console.error("  - " + f);
  console.error("\nConteúdo da raiz do repositório: " + readdirSync(".").join(", "));
  if (existsSync("src")) console.error("Conteúdo de src/: " + readdirSync("src").join(", "));
  else console.error("A pasta src/ NÃO existe. Envie o projeto com 'git add .' e 'git push' (não pelo botão Upload files do GitHub).");
  console.error("Se os arquivos estiverem dentro de uma subpasta, defina o Root Directory dessa subpasta na Vercel (Settings > General).\n");
  process.exit(1);
}
console.log("Arquivos do projeto conferidos.");
